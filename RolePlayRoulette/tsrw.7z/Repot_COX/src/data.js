const MissionReviewData = {
    filename: "COXX_MissionName.Desert_E",
    creationDate: '2024-06-10T11:00:00.000',
    pages: [
        {
            name: "Миссия",
            status: "OK",
            data: null,
            validation: null,
            issues: null,
            rawContent: [
                {
                    filename: "overview.jpg",
                    content: "overview.jpg",
                    language: "image"
                },
                {
                    filename: "mission.sqm",
                    content: "some_content = 10\nsome_value[] = {'Value','Value2'}",
                    language: "cpp"
                },
                {
                    filename: "description.ext",
                    content: "class MyClass {\n    int i;\n}\n\nafopasfmpmasf",
                    language: "cpp"
                }
            ]
        },
        {
            name: "dzn Gear v2.8ace",
            status: "ERROR",
        },
        {
            name: "dzn Dynai v1.3.2.1",
            status: "DISABLED",
        },
        {
            name: "tSFramework",
            status: "WARNING",
        }
    ]
}
/*

    "mission": {
        "data": {
            "title": "COXX Mission name",
            "overview": "Text text",
            "preview": "overview.jpg"
        },
        "validation": {
            "overallResult": false,
            "validators": [
                {
                    "id": 1,
                    "result": "OK"
                },
                {
                    "id": 2,
                    "result": "WARN"
                }
            ]
        },
        "issues": [
            {
                "id": 1,
                "note": "XXX AAA ZZZ"
            }
        ],
        "raw_content": "afaspo mfaposf masop fmas omfspa mfpoas mfopams f\n\noapsfmamopsfmapsomfapsof\n\nafopasfmpmasf"
    }
*/