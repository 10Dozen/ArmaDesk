'''
Input - path to mission folder
'C:\Users\Admin\Downloads\CO23_The_Unquenchable_Fire.Desert_E'

1) Read mission.sqm data 
2) Read description.ext data 

3) Read dzn_gear
4) dzn_dynai

5) Brieing
6) IntroText

'''


