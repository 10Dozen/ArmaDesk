class CfgDebriefing
{  
    class Win
    {
        title = "Задание выполнено";
        subtitle = "Успех!";
        description = "Задача выполнена";
    };                  
    class Lose
    {
        title = "Задание провалено";
        subtitle = "Провал!";
        description = "Задача не была выполнена";
    };
};
