This is a Simple Mission Idea Generator that punch your fantasy with random idea.

Open in any modern browser and make missions!
